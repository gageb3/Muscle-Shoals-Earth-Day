$(document).ready(function () {
  console.log("doc is ready");
}